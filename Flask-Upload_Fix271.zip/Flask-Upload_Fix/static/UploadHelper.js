class UploadZipFile{
    constructor(){
        this.size=0;
        //Move to Constant class
        this.allowedSize = 10485760;
        this.maxSize = 504857600;
        this.maxUploadTry = 3;
        this.fileList = [];
        this.IsFileComplete = false;
        this.IsUploaded = false;
        this.uploadtry = 0;
        this.IsUploadInprogress = false;
    }

    AddFile(file){
        //Reject File that's bigger than 500MB -> IsComplete : false, AddFile : false
        if(file.size > this.maxSize){
            return false;
        }

        //Files greater than 10MB, add as a separate upload file -> IsComplete : true, AddFile : true
        if(this.size==0 && file.size > this.allowedSize && file.size < this.maxSize){
            this.addFileToList(file);
            this.finalizeZipFile();
            return true;
        }

        //If File to added, makes upload file cross 10MB let it be added to a new file
        //-> IsComplete : true, AddFile : false
        if(this.size + file.size > this.allowedSize){
            this.finalizeZipFile();
            return false;
        }

        //-> IsComplete : false, AddFile : true
        this.addFileToList(file);
        return true;
    }

    addFileToList(file){
        this.size = this.size + file.size;
        this.fileList.push(file);
    }

    finalizeZipFile(){
        this.IsFileComplete = true;
    }

}

class UploadActivity{
    static Instance;
    
    constructor(files){
        this.files = files;
        this.totalSize = 0;
        this.uploadSize = 0;
        this.splitFiles = [];
        
    }

    static InitializeUpload(files){
        this.Instance = new UploadActivity(files);
        this.Instance.SplitFilesBySize();
    }

    Upload(numWorkers){

    }

    SplitFilesBySize(){
        console.log("SplitFilesBySize File Count: "+this.files.length);
        
        let uploadZipFile = new UploadZipFile();
        
        for (let i = 0; i < this.files.length; i++) {
            let file = this.files[i],
            name = file.webkitRelativePath || file.name;
            let isFileAdded = false;  
            while(!isFileAdded){
                
                isFileAdded = uploadZipFile.AddFile(file);

                if(!isFileAdded && !uploadZipFile.IsFileComplete){
                    //Not able to handle large size file
                    //Handle separately.
                    isFileAdded = true;
                    continue;
                }

                if(uploadZipFile.IsFileComplete){
                    this.splitFiles.push(uploadZipFile);
                    uploadZipFile = new UploadZipFile();  
                    continue;
                }
            }

            this.totalSize = file.size;

        }
        console.log("SplitFilesBySize SplitFile Count: "+this.splitFiles.length);

    }
}

    
